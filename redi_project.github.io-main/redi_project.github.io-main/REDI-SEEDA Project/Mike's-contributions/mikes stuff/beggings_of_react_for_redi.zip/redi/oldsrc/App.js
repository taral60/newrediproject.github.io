import React,{Component} from 'react';
import Products from './Products';
import logo from './logo.svg';
import './App.css';
import {Button} from 'react-bootstrap';
import JumboTronComponent from './JumboTronComponent';
import Rating from './Rating';
import UserForm0 from './UserForm0';
import GitHub from './GitHub';
import {BrowserRouter, Route, Switch} from 'react-router-dom';
import {Nav, Navbar} from 'react-bootstrap';
import GitHubUser from './GitHubUser'
import * as firebase from 'firebase';
import 'bootstrap/dist/css/bootstrap.min.css';
import User from './User';
import UserForm from './UserForm';


//class base allows the componant to attach object with properties or methods
 class App extends Component {
  constructor(){
    super();
    //console.log(firebase);
  }
   render(){
    const isValid = true;
  
    return (
      <div>
        <Header />
      </div>
    );
    
    
      //   <div>
      //   <JumboTronComponent>
      //     this is the song that never ends
      //   </JumboTronComponent>
      //   <Products />
      //   <UserForm0 />
      //   <GitHub />        
      // </div>
    //);
 
      // <div className="App">
      //   <h1>
      //     Hello World!
      //   </h1>
      //   <Button variant="danger">Default</Button>
      //   <Button variant="primary" disabled={!isValid}>Default2</Button>
      //   <Products />
      //   <Rating rating="1"/>
      //   <Rating rating="2"/>
      //   <Rating />
      // </div>
    //)
  }
}

//import React from 'react';
//componants can be class based or functional base like bellow
/*function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}*/

export default App;

//specific routs should be at top generic should be at bottom like below
//rap routs in switch so assures only the one is displayed  
class Header extends Component {
  render(){
    return(
      <BrowserRouter>
        <div>
          <Navbar bg="light" expand="lg">
            <Navbar.Brand href="#home">
              React-Boot-strap
            </Navbar.Brand>
            <Navbar.Toggle aria-controls="basic-navbar-nav" />
            <Navbar.Collapse id="basic-navbar-nav">
              <Nav className="mr-auto">
                <Nav.Link href="/">Home</Nav.Link>
                <Nav.Link href="/github">Github</Nav.Link>
                <Nav.Link href="/products">products</Nav.Link>
                <Nav.Link href="/user">user</Nav.Link>
              </Nav>
            </Navbar.Collapse>
          </Navbar>


          <Switch>
            <Route path="/edit/:id" component={UserForm} />
            <Route path="/add" component={UserForm} />
            <Route path="/user" component={User} />
            <Route path="/github/user/:login/:id" component={GitHubUser} />
            <Route path="/products" component={Products} />
            <Route path="/github" component={GitHub} />
            <Route exact path="/" component={Home} />
            <Route path="/*" component={NotFound} />
          </Switch>
        </div>
      </BrowserRouter>
    );
  }
}

class Home extends Component {
  render(){
    return(
      <div>
        Home
      </div>
    );
  }
}

class NotFound extends Component {
  render(){
    return(
      <div>
        Not Found
      </div>
    );
  }
}