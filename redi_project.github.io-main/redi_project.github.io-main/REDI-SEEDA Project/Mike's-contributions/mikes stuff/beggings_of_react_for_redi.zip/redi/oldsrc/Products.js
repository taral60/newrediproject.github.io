import React, {Component} from 'react';
import Product from './Product';

class Products extends Component {
    //object methods can now be shortand to name(){}
    // formatName(user){
    //     return user.firstName +''+ user.lastName
    // }

    products;

    constructor(props){
        super(props);
        this.products=this.getProducts();
    }

    
    //where the actuall data goes
    getProducts() {
        return [
        { 
            imageUrl: "http://loremflickr.com/150/150?random=1",
            productName: "Product 1",
            releasedDate: "May 31, 2016",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean porttitor, tellus laoreet venenatis facilisis, enim ex faucibus nulla, id rutrum ligula purus sit amet mauris. ",        
            rating: 4,
            numOfReviews: 2
        },
        { 
            imageUrl: "http://loremflickr.com/150/150?random=2",
            productName: "Product 2",
            releasedDate: "October 31, 2016",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean porttitor, tellus laoreet venenatis facilisis, enim ex faucibus nulla, id rutrum ligula purus sit amet mauris. ",        
            rating: 2,
            numOfReviews: 12          
        },
        { 
            imageUrl: "http://loremflickr.com/150/150?random=3",
            productName: "Product 3",
            releasedDate: "July 30, 2016",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean porttitor, tellus laoreet venenatis facilisis, enim ex faucibus nulla, id rutrum ligula purus sit amet mauris. ",        
            rating: 5,
            numOfReviews: 2
        }];
    }   
    
    render(){
        const listProducts=this.products.map((product) => <Product key={product.productName} data={product} />);

        //can also do {listProducts.length > 0?(<ul>{listProducts}</ul>):(<ul>No Products to display.</ul>)}
        return (
            <div>
                {listProducts.length > 0 && <ul>{listProducts}</ul>}
                {listProducts == 0 && <ul>No Products to display.</ul>}
            </div>
        );
    }

    // render(){
    //     const user = {
    //         firstName:'Mike',
    //         lastName:'Kline'
    //     }

    //     const products=["learning react","pro React","beginning React"];
    //     const listProducts = products.map((product)=><li key={product.toString()}>{product}</li>);
        
    //     //that that will be exported is inside the render
    //     return(
    //         <div>
    //             <h1>Hello, {this.formatName(user)}</h1>
    //             <h2>
    //                 Products
    //             </h2>
    //             <img src={user.imageURL}></img>
    //             <ul>{listProducts}</ul>
    //         </div>
    //     );
    // }
}
export default Products;

