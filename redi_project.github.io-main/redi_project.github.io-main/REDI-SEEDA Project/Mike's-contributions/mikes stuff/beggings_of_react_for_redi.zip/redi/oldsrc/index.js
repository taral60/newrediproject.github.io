import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as firebase from 'firebase';
import * as serviceWorker from './serviceWorker';
import 'bootstrap/dist/css/bootstrap.min.css';

//config for firebase
var firebaseConfig = {
  apiKey: "AIzaSyAmO2CmY2b3Ndxi9F-FzzovEVxg4gIbDg0",
  authDomain: "learning-react-84b8e.firebaseapp.com",
  databaseURL: "https://learning-react-84b8e.firebaseio.com",
  projectId: "learning-react-84b8e",
  storageBucket: "learning-react-84b8e.appspot.com",
  messagingSenderId: "870542447890",
  appId: "1:870542447890:web:061d31acd217389b6ecfcb",
  measurementId: "G-F9Y7ZTBM4G"
};


firebase.initializeApp(firebaseConfig);
ReactDOM.render(
 // <React.StrictMode>
    <App />,
 // </React.StrictMode>,
  document.getElementById('root')
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
